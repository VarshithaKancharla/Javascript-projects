$(document).ready(function(){
    $("button").click(function(){
        var username=$("#username").val()
        var email=$("#email").val()
        var password=$("#password").val()
        var cpassword=$("#cpassword").val()

        checkusername(username)
        checkemail(email)
        checkpassword(password)
        checkcpassword(password,cpassword)
    
})})


function checkusername(username){
    if(username.length>7){
        $("#username").css('border','3px solid green');
        $("#username_error").html('');
    }
    else{
        $("#username").css('border','3px solid red');
        $("#username_error").html('username should not be less than 7 characters')
    }
}
function checkemail(email){
    if(email.length>7 && email.includes('@gmail.com')){
        $("#email").css('border','3px solid green');
        $("#email_error").html('');
    }
    else{
        $("#email").css('border','3px solid red');
        $("#email_error").html('email should be 8 characters long and contain @gmail.com')
    }
}
function checkpassword(password){
    if(password.length>7 && password.includes('.')){
        $("#password").css('border','3px solid green');
        $("#password_error").html('');
    }
    else{
        $("#password").css('border','3px solid red');
        $("#password_error").html('password should be 8 characters long and contain "."')
    }
}
function checkcpassword(password,cpassword){
    if(cpassword==password){
        $("#cpassword").css('border','3px solid green');
        $("#cpassword_error").html('');
    }
    else{
        $("#cpassword").css('border','3px solid red');
        $("#cpassword_error").html('password not matched')
    }
}
