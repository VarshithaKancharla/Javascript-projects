function inc(){
    var number=Number(document.getElementById("number").innerHTML)
    document.getElementById("number").innerHTML=number+1
}
function dec(){
    var number=Number(document.getElementById("number").innerHTML)
    document.getElementById("number").innerHTML=number-1
}
function rst(){
    document.getElementById("number").innerHTML=0
}